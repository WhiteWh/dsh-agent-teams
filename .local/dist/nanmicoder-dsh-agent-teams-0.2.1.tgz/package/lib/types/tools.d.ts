/**
 * The `agent_teams_*` model-facing tools.
 *
 * The captain (the agent that created the team) orchestrates: members are
 * continuable subagents it spawns and wakes. Members share the same tools and
 * drive their own task state, mirroring the Claude Code AgentTeams flow:
 * create team → add members → create tasks with dependencies → claim/assign →
 * work → report → status → delete.
 * @module dsh-agent-teams/tools
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { type TeamState, type TeamTask } from './types.ts';
export { steerCaptainReport } from './members.ts';
/** Resolved plugin config consumed by the tools. */
export interface ToolsConfig {
    /** State directory name under the captain's workspace. */
    stateDir: string;
    /** Member subagent provider name. */
    memberProvider: string;
    /** Optional member model override. */
    memberModel?: string;
    /** Prompt injected into member personas and assignments. */
    executionPrompt?: string;
    /** Plugin fallback route. */
    fallback?: import('./profiles.ts').TeamModelFallbackConfig;
    /** Member delegation depth cap. */
    memberMaxDepth?: number;
    /** Team size cap (members). */
    maxMembers: number;
    /** Named team profiles from the active DSH profile. */
    profiles: Record<string, import('./profiles.ts').TeamProfileConfig>;
    /**
     * Every workspace the host knows, for the phase-2 scheduler sweep. The host
     * injects this (it owns the workspace registry); absent means "the calling
     * captain's workspace only", which is what tests and older hosts get.
     */
    workspaces?: () => readonly string[];
    /**
     * Per-team concurrent-worker cap (WP11 phase 2). Defaults to
     * `MAX_WORKERS_PER_TEAM`; phase 3 exposes it as a profile key.
     */
    maxWorkersPerTeam?: number;
    /** Workspace-wide concurrent-worker cap; defaults to `MAX_CONCURRENT_WORKERS_GLOBAL`. */
    maxConcurrentWorkersGlobal?: number;
    /** Live teams one workspace may hold (WP11 phase 3; default `MAX_TEAMS_PER_WORKSPACE`). */
    maxTeamsPerWorkspace?: number;
    /** Live teams one captain session may lead (WP11 phase 3; default `MAX_TEAMS_PER_SESSION`). */
    maxTeamsPerSession?: number;
}
/** Browser/UI mutations allowed while a plan is waiting for approval. */
export type StagedPlanMutation = {
    action: 'update_member';
    memberName: string;
    role?: string | null;
    provider: string;
    model: string;
    reasoningEffort?: string | null;
    executionPrompt?: string | null;
} | {
    action: 'update_task';
    taskId: string;
    subject: string;
    description?: string | null;
    assignee?: string | null;
    dependencies: string[];
} | {
    action: 'add_task';
    subject: string;
    description?: string | null;
    assignee?: string | null;
    dependencies: string[];
} | {
    action: 'remove_task';
    taskId: string;
} | {
    action: 'remove_member';
    memberName: string;
};
/** The result the Web surface and the tool both report for one replan batch. */
export interface ReplanRuntimeResult {
    readonly revision: number;
    readonly applied: number;
    readonly changes: string[];
    readonly added: string[];
    readonly removed: string[];
    readonly rebound: string[];
    readonly invalidated: string[];
}
/** Runtime bridge shared by model-facing tools and the Web staging surface. */
export interface AgentTeamsRuntime {
    isPendingMember(agent: Agent): boolean;
    updateStagedPlan(captain: Agent, teamId: string, mutation: StagedPlanMutation, signal?: AbortSignal): Promise<TeamState>;
    updateStagedPlanBatch(captain: Agent, teamId: string, mutations: readonly StagedPlanMutation[], signal?: AbortSignal): Promise<TeamState>;
    approveStagedTeam(captain: Agent, teamId: string, signal?: AbortSignal): Promise<{
        teamId: string;
        members: number;
        tasks: number;
    }>;
    continueStagedPlanning(captain: Agent, teamId: string): Promise<{
        teamId: string;
        alreadyWaiting: boolean;
    }>;
    discardStagedTeam(captain: Agent, teamId: string): Promise<{
        teamId: string;
    }>;
    /**
     * WP7/S17: revise a RUNNING plan in one atomic batch. Shared by
     * `agent_teams_replan` and the Web running-mode plan editor, so both paths
     * validate, write, emit the same event and wake the same members.
     */
    replanLiveTeam(captain: Agent, teamId: string, operations: readonly import('./replan.ts').ReplanOperation[], reason: string, signal?: AbortSignal): Promise<ReplanRuntimeResult>;
}
/** Live teams one workspace may hold (WP11 phase 1 default; configurable in phase 3). */
export declare const MAX_TEAMS_PER_WORKSPACE = 4;
/** Live teams one captain session may lead (WP11 phase 3 default). */
export declare const MAX_TEAMS_PER_SESSION = 8;
/** Workspace-wide active-worker fuse for WP11 phase 1 (owner decision D6). */
export declare const MAX_CONCURRENT_WORKERS_GLOBAL = 8;
export declare function haltTeamWork(input: {
    ctx: Context;
    stateRoot: string;
    teamId: string;
    captain: Agent;
    signal?: AbortSignal;
}): Promise<{
    teamName: string;
    cancelledTasks: number;
    alreadyHalted: boolean;
}>;
/** Web approval has no tool result in the captain's conversation. */
export declare function stagedPlanApprovedContext(teamName: string): string;
/** Context queued after the human rejects a staged plan. */
export declare function stagedPlanDiscardContext(teamName: string): string;
/** Model-facing continuation that turns the review UI back into a conversation. */
export declare function stagedPlanFeedbackContext(teamName: string): string;
/**
 * Register every `agent_teams_*` tool into the shared tools registry.
 * @param ctx - the plugin context (injects `tools`).
 * @param config - resolved tool config.
 */
export declare function registerAgentTeamsTools(ctx: Context, config: ToolsConfig): AgentTeamsRuntime;
export declare function applyQualityFollowUp(team: TeamState, closed: TeamTask): {
    created: TeamTask[];
    escalated: boolean;
};
