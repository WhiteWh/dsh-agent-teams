/**
 * Named team-profile templates: config types, normalization, invocation
 * parsing, and prompt rendering.
 *
 * Pure functions only — no I/O, no spawn. Runtime create/spawn stays in
 * `tools.ts`; this module only turns a config map + a profile name into a
 * validated, topologically ordered template (or parses `--profile` flags).
 *
 * @module dsh-agent-teams/profiles
 */
/** Hard cap on named profiles so the usage prompt cannot grow without bound. */
export declare const MAX_TEAM_PROFILES = 16;
/** Hard cap on seed tasks per profile. The software-delivery example has 13. */
export declare const MAX_PROFILE_TASKS = 32;
/** Protocol excerpt length in the usage / prompt listing. */
export declare const PROFILE_PROTOCOL_PROMPT_LIMIT = 240;
/**
 * Where each nested key set lives inside a profile body. Used for two things:
 * validating a profile before it is saved or activated, and turning an unknown
 * key into a correction instead of a bare "is unknown".
 */
interface ProfileKeyScope {
    /** The nested key set that belongs at this level. */
    readonly keys: readonly string[];
    /** Scope name for a hint such as "belongs under reviewPolicy". */
    readonly label?: string;
}
/**
 * Find where a misplaced key belongs.
 *
 * The incident (feedback §6.1) was a profile with `requiredReviewers` at the top
 * level: the real schema wants it under `reviewPolicy`, and the error the
 * captain got — `profiles.material-layers.requiredReviewers is unknown` — named
 * neither the nesting nor the fix. Levenshtein distance cannot bridge that gap
 * (distance 15), so unknown keys are looked up in the nested key sets too.
 *
 * @param unknown - the rejected key name.
 * @param scopes - the nested scopes to search, in report order.
 * @returns the suggested replacement, or undefined when nothing plausible fits.
 */
export declare function suggestNestedProfileKey(unknown: string, scopes: readonly ProfileKeyScope[]): {
    key: string;
    label: string;
} | undefined;
/** One member row in a named team-profile template (unresolved). */
export interface TeamModelFallbackConfig {
    provider: string;
    model: string;
}
export interface TeamProfileMemberConfig {
    name: string;
    role?: string;
    provider?: string;
    model?: string;
    reasoning_effort?: string;
    executionPrompt?: string;
    fallback?: TeamModelFallbackConfig;
}
/** One seed-task row in a named team-profile template (unresolved). */
export interface TeamProfileTaskConfig {
    id: string;
    subject: string;
    description?: string;
    assignee?: string;
    dependencies?: string[];
}
/** One named team-profile template from plugin config. */
export interface TeamProfileConfig {
    description?: string;
    protocol?: string;
    executionPrompt?: string;
    fallback?: TeamModelFallbackConfig;
    members: TeamProfileMemberConfig[];
    /**
     * `captain` means the profile supplies people and guardrails only; the
     * Captain derives the task graph from the user's goal at runtime.
     * `seed` preserves a fixed template workflow for explicitly scripted teams.
     */
    taskPlanning?: 'captain' | 'seed';
    tasks?: TeamProfileTaskConfig[];
    reviewPolicy?: import('./types.ts').ReviewPolicy;
}
/** A profile member after trim / pairing / reserved-name checks. */
export interface NormalizedProfileMember {
    name: string;
    role?: string;
    provider?: string;
    model?: string;
    reasoningEffort?: string;
    executionPrompt?: string;
    fallback?: TeamModelFallbackConfig;
}
/** A profile seed task after assignee canonicalization; `sourceIndex` is the YAML order. */
export interface NormalizedProfileTask {
    id: string;
    subject: string;
    description?: string;
    assignee?: string;
    dependencies: string[];
    sourceIndex: number;
}
/** A fully validated, topologically ordered team profile. */
export interface NormalizedTeamProfile {
    name: string;
    description?: string;
    protocol?: string;
    executionPrompt?: string;
    fallback?: TeamModelFallbackConfig;
    taskPlanning: 'captain' | 'seed';
    /** Paths every implementation/repair task of this profile inherits (WP4/S10). */
    sharedInScope?: string[];
    /** Progress weighting frozen into the team, from `taskPlanning.weights` (WP8/S16). */
    progressWeights?: 'equal' | Record<string, number>;
    /** Declared plan phases (`taskPlanning.phases`, WP7/S17), empty task lists. */
    phases?: import('./types.ts').TeamPlanPhase[];
    members: NormalizedProfileMember[];
    tasks: NormalizedProfileTask[];
    reviewPolicy?: import('./types.ts').ReviewPolicy;
}
/** The goal + optional named profile extracted from a slash / gesture line. */
export interface AgentTeamsInvocation {
    goal: string;
    profile?: string;
}
/** One configured profile after key trim, for listing / lookup. */
export interface ListedTeamProfile {
    name: string;
    config: TeamProfileConfig;
}
/**
 * Trim every profile key once, reject empty / colliding keys, and reject
 * more than {@link MAX_TEAM_PROFILES} entries. Does not validate profile
 * bodies — that belongs to {@link resolveTeamProfile}.
 */
export declare function listConfiguredProfiles(profiles: Record<string, TeamProfileConfig> | undefined | null): ListedTeamProfile[];
/**
 * Render the usage-prompt listing. One line per profile: name, member count,
 * task count, protocol excerpt (at most 240 characters). Returns `''` when
 * nothing is configured so callers can omit the capability entirely.
 */
export declare function formatProfilesForPrompt(profiles: Record<string, TeamProfileConfig> | undefined | null): string;
/**
 * Walk `rawInput` from the front and eat standalone profile flags. Only
 * `--profile <name>`, `--profile=<name>`, and `profile=<name>` count; the
 * first ordinary token stops the scan so a mid-sentence `profile=` stays in
 * the goal. A leading ordinary token is never treated as a profile name.
 *
 * `--profile "name"` strips one matching pair of quotes. Repeat flags and a
 * `--profile` with no name throw.
 */
export declare function parseProfileInvocation(rawInput: string): AgentTeamsInvocation;
/**
 * Normalize and pre-validate one named profile. Failures throw before any
 * caller should create a directory or spawn members.
 */
export declare function resolveTeamProfile(profiles: Record<string, TeamProfileConfig>, profileName: string, maxMembers: number): NormalizedTeamProfile;
/**
 * Validate only the key structure of every configured profile and print the
 * exact problem with its path.
 *
 * This is the lint entry point behind
 * `node scripts/doctor.mjs --profiles <config>`. It deliberately stops short of
 * {@link resolveTeamProfile}: resolving needs `maxMembers`, evaluates model
 * routes and normalizes seed tasks, so it cannot run outside a live host. The
 * key structure is what makes a profile unusable — an unknown key aborts
 * `agent_teams_create` with a message the captain cannot act on unless it names
 * the nesting (feedback §6.1) — so that is what a config-only lint can check
 * honestly.
 *
 * @param profiles - the raw configured profile map.
 * @returns one entry per profile, with the message or undefined when it is valid.
 */
export declare function lintProfileKeys(profiles: Record<string, TeamProfileConfig> | undefined | null): {
    name: string;
    ok: boolean;
    error?: string;
}[];
/**
 * Find the `profiles` map inside an arbitrary config document.
 *
 * The plugin config is written in several shapes in practice: a bare
 * `{profiles: {...}}`, a `{plugins: {'agent-teams': {...}}}` block, or a
 * composed DSH profile (`cordis.patch.yml` / `cordis.yml`) whose plugin entry
 * carries a `config` object. Rather than guess one, search the document for the
 * first map whose values look like profile definitions (`{members: [...]}`) or
 * for a key literally named `profiles`.
 *
 * @param raw - the parsed config document.
 * @returns the profile map, or `undefined` when the document carries none.
 */
export declare function findProfilesInConfig(raw: unknown): Record<string, TeamProfileConfig> | undefined;
/** Public lookup used by activation text and status rendering. */
export declare function resolveProfileTaskPlanning(config: TeamProfileConfig | undefined): 'captain' | 'seed';
/**
 * Paths every implementation/repair task inherits, from the creating profile's
 * `taskPlanning.sharedInScope` (WP4/S10). They are added to the task's `inScope`
 * and excluded from the overlap comparison, so two sibling lanes can both touch
 * generated documentation without being treated as a scope conflict.
 */
export declare function resolveProfileSharedInScope(config: TeamProfileConfig | undefined): string[] | undefined;
/**
 * The frozen progress weighting of a profile, from `taskPlanning.weights`
 * (WP8/S16): `'equal'` makes the equal count the team default, a table replaces
 * single kind weights, `undefined` keeps the built-in kind table.
 */
export declare function resolveProfileProgressWeights(config: TeamProfileConfig | undefined): 'equal' | Record<string, number> | undefined;
export {};
