/**
 * Event-driven shared task scheduler.
 *
 * Claude Code teammates keep polling the shared task list after a turn. DSH
 * continuable agents instead expose explicit idle/running edges, so this
 * scheduler closes the same loop without keeping a polling turn alive: every
 * idle edge and every task-graph mutation attempts one atomic claim and wakes
 * the selected durable member. A resident member that becomes idle while it
 * still owns an open attempt is parked: only an explicit captain reassignment
 * may rotate that capability. Automatic retry is reserved for cold recovery,
 * when this process has not observed the durable owner settle its open attempt.
 * @module dsh-agent-teams/scheduler
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { AcceptanceCriterion, TeamTask } from './types.ts';
/** Per-dependency output cap in the assignment prompt. */
export declare const DEPENDENCY_OUTPUT_MAX_CHARS = 2000;
/** Combined dependency-output budget in the assignment prompt. */
export declare const DEPENDENCY_OUTPUTS_TOTAL_MAX_CHARS = 12000;
/**
 * How many members of one team may be dispatched at the same time (WP11 phase 2).
 *
 * The upstream `maxConcurrentWorkers` mechanics: a fuse on concurrent work, not a
 * limit on the roster. The default equals the default roster cap (8), so an
 * existing team is never silently throttled; a host or profile lowers it on
 * purpose, and phase 3 exposes the key on the profile.
 */
export declare const MAX_WORKERS_PER_TEAM = 8;
/** How many members may work at once across every live team of the workspace. */
export declare const MAX_CONCURRENT_WORKERS_GLOBAL = 8;
export interface SchedulerConfig {
    readonly stateDir: string;
    readonly executionPrompt?: string;
    readonly dispatch?: (captain: Agent, teamId: string, memberName: string, text: string, signal: AbortSignal, mode: 'queue' | 'steer', attemptId?: string) => Promise<boolean>;
    /**
     * Every workspace the host knows (WP11 phase 2), used by {@link TeamScheduler.sweepAll}.
     * Omitted in tests and in hosts without a workspace registry, where the sweep
     * falls back to the workspace of the calling captain.
     */
    readonly workspaces?: () => readonly string[];
    /** Per-team concurrency cap; defaults to {@link MAX_WORKERS_PER_TEAM}. */
    readonly maxWorkersPerTeam?: number;
    /** Workspace-wide concurrency cap; defaults to {@link MAX_CONCURRENT_WORKERS_GLOBAL}. */
    readonly maxConcurrentWorkersGlobal?: number;
}
export interface TeamScheduler {
    /** Try to give every genuinely idle/ready member one unit of ready work. */
    kickTeam(workspace: string, teamId: string, captain?: Agent): Promise<void>;
    /** Try to flush fallback mail or give one member one ready task. */
    kickMember(workspace: string, teamId: string, memberName: string, captain?: Agent): Promise<boolean>;
    /**
     * Sweep every live team of every known workspace (WP11 phase 2).
     *
     * The phase-1 scheduler only ever moved the team whose tool call woke it, so a
     * second team could sit with ready work until something touched it. The sweep
     * visits all live teams, honours the per-team and global worker caps, and never
     * gives a member a second task (a member belongs to exactly one team, and
     * {@link TeamScheduler.kickMember} refuses a member that already holds work).
     *
     * @param captain - the live captain asking for the sweep, when there is one.
     * @returns how many teams were visited and how many members were dispatched.
     */
    sweepAll(captain?: Agent): Promise<{
        readonly teams: number;
        readonly dispatched: number;
    }>;
    /**
     * Record a capability the plugin minted for a member outside a dispatch
     * (`claim_task`). The scheduler must never treat one of these as a lost owner
     * and re-claim the task underneath the member; see the note on the recovery
     * marker in {@link installTeamScheduler}.
     */
    noteClaimedAttempt(memberId: string, attemptId: string): void;
}
/** One completed recursive dependency shown to the assignee. */
export interface DependencyOutput {
    readonly id: string;
    readonly subject: string;
    readonly profileSeedId?: string;
    readonly output?: string;
}
export interface DispatchTicket {
    readonly taskId: string;
    readonly memberName: string;
    readonly memberId: string;
    readonly attempt: number;
    readonly attemptId: string;
    readonly previousAssignee?: string;
    /** True when this ticket rotates an unobserved durable open attempt. */
    readonly recoveredOwned: boolean;
    /** Original task generation, used to restore a failed automatic recovery. */
    readonly previousStatus?: 'claimed' | 'in_progress';
    readonly previousAttempt?: number;
    readonly previousAttemptId?: string;
    readonly subject: string;
    readonly description?: string;
    readonly teamDescription?: string;
    readonly profileProtocol?: string;
    readonly profileSeedId?: string;
    readonly dependencyOutputs: readonly DependencyOutput[];
    readonly executionPrompt?: string;
    readonly kind?: string;
    readonly round?: number;
    readonly objective?: string;
    readonly inScope?: readonly string[];
    readonly outOfScope?: readonly string[];
    readonly acceptance?: readonly (string | AcceptanceCriterion)[];
    readonly verify?: readonly string[];
    readonly reviewedTaskId?: string;
}
/**
 * Recursively collect `status=completed` ancestors of `taskId` in topological
 * order (dependencies before dependents). Cycles stop that branch only.
 */
export declare function collectCompletedDependencyOutputs(tasks: readonly TeamTask[], taskId: string, warn?: (message: string) => void): DependencyOutput[];
/** Format completed-dependency outputs with per-item and total truncation. */
export declare function formatDependencyOutputs(items: readonly DependencyOutput[]): string;
export declare function assignmentPrompt(ticket: DispatchTicket, stateDir: string, teamId: string): string;
/** Install one scheduler and its member activity observer. */
export declare function installTeamScheduler(ctx: Context, config: SchedulerConfig): TeamScheduler;
