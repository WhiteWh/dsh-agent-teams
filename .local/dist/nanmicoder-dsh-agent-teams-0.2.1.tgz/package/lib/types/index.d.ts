/**
 * AgentTeams for DeepSeek Harness.
 *
 * A host-plane plugin that registers the `agent_teams_*` tools and one usage
 * agent-scoped usage section. Each session keeps a stable tool set and core
 * instructions. Existing business tools cover the complete team lifecycle.
 * After installation any session can
 * run multi-agent teamwork through natural language (e.g. "use AgentTeams to research X"):
 * the model creates a team (it becomes the captain), spawns members as
 * durable continuable subagents, breaks the goal into tasks with
 * dependencies, wakes members with messages, relays reports, and collects
 * results.
 *
 * Installation (bundle): `dsh plugin --profile <name> add @nanmicoder/dsh-agent-teams`
 * (or a local path). The bundle patch mounts this plugin row into the host
 * composition; the tools register into the shared `tools` registry and the
 * usage section into the global system prompt, so the plugin needs no realm.
 *
 * @module dsh-agent-teams
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type TeamProfileConfig } from './profiles.ts';
export declare const name = "@nanmicoder/dsh-agent-teams";
export declare const inject: string[];
/** Plugin configuration. */
export interface Config {
    /**
     * State directory name under the captain's workspace; team state lives at
     * `<workspace>/<stateDir>/<teamId>/` (default `.agent-teams`).
     */
    stateDir?: string;
    /** `ctx.subagents` provider used to spawn members; must support continuable children and personas (default `spawn`). */
    memberProvider?: string;
    /** Optional model override applied to every member. */
    memberModel?: string;
    /** Prompt injected into member personas and automatic task assignments. */
    executionPrompt?: string;
    /** Plugin-wide fallback route for unavailable member models. */
    fallback?: import('./profiles.ts').TeamModelFallbackConfig;
    /** Member delegation depth cap (default `0`; `0` forbids delegation entirely). */
    memberMaxDepth?: number;
    /** Team size cap in members (default `8`). */
    maxMembers?: number;
    /**
     * Members of one team that may work at the same time (WP11 phase 2, default
     * `4`). The upstream `maxConcurrentWorkers` mechanics: a fuse on concurrent
     * work, not a limit on the roster.
     */
    maxWorkersPerTeam?: number;
    /** Members that may work at once across every live team of the workspace (default `8`). */
    maxConcurrentWorkersGlobal?: number;
    /** Live teams one workspace may hold (WP11 phase 3, default `4`). */
    maxTeamsPerWorkspace?: number;
    /** Live teams one captain session may lead (WP11 phase 3, default `8`). */
    maxTeamsPerSession?: number;
    /** Named multi-role team profiles. */
    profiles?: Record<string, TeamProfileConfig>;
    /** Prompt-section order for the usage policy (default `117`, after delegation policy). */
    promptSectionOrder?: number;
    /**
     * Register the deterministic `/agent-teams` activation surfaces (the
     * closed-namespace slash command and the plain-text gesture boundary).
     * Disable to keep the natural-language trigger as the only entry point.
     */
    slashCommand?: boolean;
}
export declare const Config: z<Config>;
/**
 * Map one camelCase Web operation into a replan operation (WP7).
 *
 * The browser editor cannot send a readonly TS type, so this is the one place
 * that turns an untrusted JSON body into the batch shape the shared applier
 * validates. Unknown keys are ignored on purpose: the applier rejects anything
 * that matters, and a stray field must not break an otherwise valid batch.
 */
export declare function parseReplanOperation(entry: unknown, index: number): import('./replan.ts').ReplanOperation;
/** The model-facing usage policy: when and how to drive AgentTeams. */ export declare function usageSectionText(toolNames: string, profilesText?: string): string;
export declare function apply(ctx: Context, config: Config): void;
