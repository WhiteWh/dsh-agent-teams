/**
 * Replanning a live team (WP7/S17).
 *
 * Before this module the only way to fix a running plan was a cascade of
 * cancels and re-creations, which threw away every member's context and every
 * dependency edge the team had already satisfied. A replan is one batch of
 * operations applied under the team lock, validated as a whole before anything
 * is written: a task that failed on a wrong contract can be amended and retried,
 * a lane that will never finish can be superseded, a scope decision can be
 * accepted and a phase can be moved — in the same call, with one reason, and
 * with nothing persisted when any single operation is invalid.
 *
 * The applier is **pure**: it returns a new team record instead of mutating the
 * one it was given, so "any error — nothing written" is a property of the code
 * rather than a promise about the order of statements.
 *
 * @module dsh-agent-teams/replan
 */
import { type TaskKind, type TeamState } from './types.ts';
/** One operation of a replan batch. */
export type ReplanAction = 'add_task' | 'update_task' | 'supersede_task' | 'cancel_task' | 'accept_paths' | 'amend_task' | 'move_phase' | 'close_phase';
/**
 * A replan operation, in the snake_case shape the tool and the Web route receive.
 *
 * One flat shape covers all eight actions on purpose: a batch arrives from a
 * model or from the browser editor, and a per-action union would only move the
 * same field names one level down.
 */
export interface ReplanOperation {
    readonly action: ReplanAction;
    /** Target task for every action except `add_task` and `close_phase`. */
    readonly task_id?: string;
    /** `add_task`: subject; `update_task`: replacement subject. */
    readonly subject?: string;
    readonly description?: string;
    readonly assignee?: string;
    readonly dependencies?: readonly string[];
    readonly kind?: TaskKind;
    readonly round?: number;
    readonly objective?: string;
    readonly inScope?: readonly string[];
    readonly outOfScope?: readonly string[];
    readonly acceptance?: readonly (string | {
        readonly text: string;
    })[];
    readonly verify?: readonly string[];
    readonly deliverables?: readonly string[];
    readonly nonGoals?: readonly string[];
    readonly reviewedTaskId?: string;
    readonly sourceTaskId?: string;
    readonly sourceFindingIds?: readonly string[];
    readonly coverageOf?: readonly string[];
    /** `supersede_task`: an existing replacement task id. */
    readonly replacement_task_id?: string;
    /** `accept_paths`: the paths to add to `inScope`. */
    readonly paths?: readonly string[];
    /** `move_phase`: the phase to move the task into (`''` removes it from every phase). */
    readonly phase_id?: string;
    /** `move_phase`: title to give a phase that does not exist yet. */
    readonly title?: string;
    /** Per-operation reason; the batch reason is the default. */
    readonly reason?: string;
    /** `amend_task` / `accept_paths`: override the post-review contract freeze. */
    readonly force?: boolean;
    /** Live attempts (`claimed`/`in_progress`) require this to be rewritten. */
    readonly invalidate?: boolean;
    /**
     * `update_task`: put a `failed` (or scope-held) task back in the queue after its
     * contract was repaired, so the same lane runs again instead of being replaced.
     */
    readonly retry?: boolean;
}
/** One member activation the batch has to drain after the write. */
export interface ReplanInvalidation {
    readonly taskId: string;
    readonly memberName: string;
    readonly memberId: string;
    readonly previousAssignee: string;
}
/** One applied operation, as reported back to the captain. */
export interface ReplanChange {
    readonly action: ReplanAction;
    /** The task the operation touched; absent for the phase-scoped `close_phase`. */
    readonly taskId?: string;
    /** The task's subject, or the phase's id/title for `close_phase`. */
    readonly subject: string;
    readonly detail: string;
    /** Set when the batch revoked a running attempt for this task. */
    readonly invalidation?: ReplanInvalidation;
}
/** What one replan batch did. */
export interface ReplanResult {
    /** Plan revision after the batch. */
    readonly revision: number;
    readonly changes: readonly ReplanChange[];
    /** Task ids the batch created. */
    readonly added: readonly string[];
    /** Task ids the batch took out of the live graph by superseding them. */
    readonly removed: readonly string[];
    /** Task ids whose dependencies or owner the batch changed. */
    readonly rebound: readonly string[];
    /** Task ids whose running attempt the batch revoked. */
    readonly invalidated: readonly string[];
    /** Members whose only remaining work disappeared; the caller may drain them. */
    readonly invalidationDetails: readonly ReplanInvalidation[];
}
/** The outcome of one batch: the next team record plus the diff. */
export interface ReplanOutcome {
    readonly team: TeamState;
    readonly result: ReplanResult;
}
/** Batch ceiling: a replan is a repair, not a second planning session. */
export declare const MAX_REPLAN_OPERATIONS = 32;
/**
 * Apply one atomic batch to a copy of the team (WP7/S17).
 *
 * Every operation is validated against the draft before the next one runs, and
 * the returned team is a new record: the caller either writes a fully valid plan
 * or keeps the old one. A batch is refused as a whole when any operation is
 * invalid, when it would introduce a dependency cycle, or when a live attempt is
 * rewritten without `invalidate: true`.
 *
 * @param team - the current team record (never mutated).
 * @param operations - the batch, in the order the captain wants it applied.
 * @param options - the batch reason (required) and an injectable clock.
 * @returns the next team record plus the diff that was applied.
 */
export declare function replanTeam(team: TeamState, operations: readonly ReplanOperation[], options: {
    readonly reason: string;
    readonly now?: number;
}): ReplanOutcome;
