/**
 * AgentTeams activity panel: the top-right floater monitoring every team.
 *
 * Modeled on the Claude Code desktop SessionActivityPanel: a shell-overlay
 * panel that docks at the conversation's top-right edge by default, can be
 * dragged into a floating window, resized, and folded into an activity badge.
 * On wide viewports the docked panel makes the conversation column yield
 * space; narrow viewports keep a simple inset overlay. It
 * polls the host `/plugins/dsh-agent-teams/state` route for
 * server-side snapshots (durable files + live subagent activity), with a
 * collapsed badge that auto-expands once when activity appears. Archived
 * teams stay available for the owning conversation after live work ends.
 *
 * The floater mounts in ui-layout's additive `shell.overlay`; it is not a
 * conversation node — the in-conversation panel was removed in favor of this
 * always-available monitor.
 * @module dsh-agent-teams/client/activity
 */
import { type ReactNode, Component } from 'react';
import type { ModelDirectoryResolver } from '@deepseek-ai/dsh-client-ui-model-selection/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { SessionListState } from '@deepseek-ai/dsh-api-session-controller/client';
import type { AgentTeamsTranslate } from './locales.ts';
/** The top-right activity floater. Teams follow the current session: live
 * snapshots and historic card summaries are only shown while their captain
 * session is the one currently open. */
export type ActivityPanelProps = {
    readonly conversationVisible?: boolean;
    readonly sessionsList: ObservableSnapshot<SessionListState>;
    readonly modelDirectories: ModelDirectoryResolver;
    readonly openMember: (parentId: SessionId, childId: SessionId) => void;
} & PropsLocale<'agentTeams'>;
/**
 * Keeps a panel fault from taking the shell down.
 *
 * The panel is mounted into the shell's additive overlay, which does not isolate a
 * render exception: an error thrown here unmounts the host's tree and the reader is
 * left with a blank page — which is exactly what a defect in this plugin must never
 * be able to do. The boundary renders one line naming the failure instead, so the
 * conversation keeps working and the panel can be dismissed.
 *
 * It catches throws. Long work is a separate matter: the layout is memoised (see
 * `phaseBoardLayout`) precisely because a boundary cannot help against a hang.
 */
export declare class PanelErrorBoundary extends Component<{
    readonly children: ReactNode;
    readonly t?: AgentTeamsTranslate;
}, {
    readonly error: string;
}> {
    constructor(props: {
        readonly children: ReactNode;
        readonly t?: AgentTeamsTranslate;
    });
    static getDerivedStateFromError(error: unknown): {
        error: string;
    };
    render(): ReactNode;
}
export declare function ActivityPanel({ sessionsList, modelDirectories, openMember, t, conversationVisible }: ActivityPanelProps): import("react").JSX.Element | null;
