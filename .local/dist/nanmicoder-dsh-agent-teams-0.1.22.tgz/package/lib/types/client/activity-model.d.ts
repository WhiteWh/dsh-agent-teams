/** Pure relationship projections used by the AgentTeams activity panel. */
/** Minimum task shape needed to derive dependency relationships. */
export interface RelationshipTask {
    readonly id: string;
    readonly dependencies: readonly string[];
    readonly depth: number;
}
/** One dependency-depth stage in stable display order. */
export interface RelationshipStage<T extends RelationshipTask> {
    readonly depth: number;
    readonly tasks: readonly T[];
}
/** Geometry used by the compact task DAG in the activity panel. */
export interface CompactDagNode<T extends RelationshipTask> {
    readonly task: T;
    readonly x: number;
    readonly y: number;
}
/** One dependency edge routed between two compact DAG nodes. */
export interface CompactDagEdge {
    readonly from: string;
    readonly to: string;
    readonly path: string;
}
/** Complete, scrollable compact DAG projection. */
export interface CompactDagLayout<T extends RelationshipTask> {
    readonly width: number;
    readonly height: number;
    readonly nodes: readonly CompactDagNode<T>[];
    readonly edges: readonly CompactDagEdge[];
}
/** Reference-panel geometry: narrow nodes with enough room for curved edges. */
export declare const COMPACT_DAG_NODE_WIDTH = 92;
export declare const COMPACT_DAG_NODE_HEIGHT = 30;
export declare const COMPACT_DAG_COLUMN_GAP = 26;
export declare const COMPACT_DAG_ROW_GAP = 8;
/** Compact `provider/model` route, or just the model when the provider is absent. */
export declare function memberRouteLabel(member: {
    readonly provider?: string;
    readonly model?: string;
} | undefined): string;
/**
 * Compact route shown on a running task. Prefer the task's own snapshot
 * field; fall back to the assignee member when older hosts omit it.
 */
export declare function taskModelLabel(task: {
    readonly model?: string;
    readonly assignee: string;
}, members: readonly {
    readonly name: string;
    readonly provider?: string;
    readonly model?: string;
}[]): string;
/** Short model id for tight DAG/chip surfaces (`openai/gpt-5.6-sol` → `gpt-5.6-sol`). */
export declare function compactModelLabel(route: string): string;
/** A live team the current captain still owns and has not halted. */
export declare function liveCaptainTeam<T extends {
    readonly captainSessionId: string;
    readonly halted?: boolean;
}>(teams: readonly T[], sessionId: string | undefined): T | undefined;
/** Whether the captain chat should keep showing the in-progress banner. */
export declare function teamIsActive(team: {
    readonly phase?: string;
    readonly halted?: boolean;
    readonly members: readonly {
        readonly status?: string;
        readonly activity?: string;
    }[];
    readonly tasks: readonly {
        readonly status: string;
    }[];
}): boolean;
/** Compact banner copy: running members, otherwise the current planning state. */
export declare function teamProgressSummary(team: {
    readonly members: readonly {
        readonly name: string;
        readonly status?: string;
        readonly activity?: string;
        readonly currentTask?: string;
    }[];
    readonly tasks: readonly {
        readonly id: string;
        readonly subject: string;
        readonly status: string;
    }[];
}, separator: string): {
    readonly working: number;
    readonly detail: string;
};
/** Use a fill-width grid when the task graph has no real dependency edges. */
export declare function usesParallelTaskGrid<T extends RelationshipTask>(tasks: readonly T[]): boolean;
/**
 * Whether an expanded activity panel still belongs to the current session.
 *
 * The panel is mounted in the root-scoped shell overlay, so React does not
 * remount it when the conversation route changes. Ownership keeps an expanded
 * panel from leaking onto the new-session screen (or another conversation)
 * while its local open state is being reset.
 */
export declare function activityPanelExpandedForSession(open: boolean, owner: string | undefined, current: string | undefined): boolean;
/** Inputs for deciding whether genuinely new live work may expand the panel. */
export interface ActivityPanelAutoExpandInput {
    readonly alreadyAutoOpened: boolean;
    readonly pageSettled: boolean;
    readonly restoreComplete: boolean;
    readonly previousLiveTeamIds: ReadonlySet<string>;
    readonly currentLiveTeamIds: readonly string[];
}
/**
 * Auto-expand only for live teams that appear after the current session's
 * initial restore pass. Replayed cards, archived teams, and live teams restored
 * while reopening a conversation must remain behind the collapsed badge.
 */
export declare function activityPanelShouldAutoExpand({ alreadyAutoOpened, pageSettled, restoreComplete, previousLiveTeamIds, currentLiveTeamIds, }: ActivityPanelAutoExpandInput): boolean;
/**
 * Resolve the task whose dependency chain should be highlighted.
 *
 * A pinned task is an explicit user choice. Keyboard focus takes precedence
 * over delayed pointer intent so an older hover timer cannot steal the active
 * chain from someone navigating the task map with the keyboard.
 */
export declare function dependencyFocusTaskId(pinnedTaskId: string | null, keyboardTaskId: string | null, hoverTaskId: string | null): string | null;
/** Group tasks by their precomputed dependency depth. */
export declare function taskStages<T extends RelationshipTask>(tasks: readonly T[]): readonly RelationshipStage<T>[];
/**
 * Lay tasks out as the reference panel's compact left-to-right DAG.
 *
 * Columns are dependency-depth stages. Rows are stable task-id order within
 * each stage. Edges use cubic curves so fan-in remains readable without
 * turning every task into a large card.
 */
export declare function compactDagLayout<T extends RelationshipTask>(tasks: readonly T[]): CompactDagLayout<T>;
/** One task as the three cuts need to see it. */
export interface PhaseTask {
    readonly id: string;
    readonly subject?: string;
    readonly status: string;
    readonly assignee: string;
    readonly dependencies: readonly string[];
    readonly state?: string;
    readonly kind?: string;
    readonly round?: number;
    readonly depth?: number;
    /** Set on a review task: the task it judges, used for the waiting-review reason. */
    readonly reviewedTaskId?: string;
}
/** One member row the three cuts need to see. */
export interface ProjectionMember {
    readonly id?: string;
    readonly name: string;
    readonly activity?: string;
    readonly status?: string;
    readonly done?: number;
    readonly total?: number;
    readonly currentTask?: string;
    readonly unread?: number;
}
/** A manually declared phase (comes from `plan.phases` once WP7 lands). */
export interface ManualPhase {
    readonly id: string;
    readonly title?: string;
    readonly taskIds: readonly string[];
}
/** One phase column of the phases view. */
export interface PhaseColumn<T extends PhaseTask> {
    /** `level-N` for a derived column, or the manual phase id. */
    readonly phaseId: string;
    readonly order: number;
    readonly title?: string;
    readonly tasks: readonly T[];
}
/**
 * Phase columns for the phases view.
 *
 * Manual phases win when they are present (WP7 stores them in `plan.phases`);
 * every task they do not mention falls back into an auto-derived column built
 * from the DAG levels, so a partially declared plan still renders completely.
 * Levels are computed here from the task list, not read from the snapshot's
 * `depth`, so the column count cannot silently disagree with the dependency
 * edges the panel draws.
 *
 * @param tasks - the team's tasks.
 * @param manualPhases - optional declared phases.
 * @returns the columns in display order, left to right.
 */
export declare function phaseColumns<T extends PhaseTask>(tasks: readonly T[], manualPhases?: readonly ManualPhase[]): readonly PhaseColumn<T>[];
/** One participant lane of the agents view. */
export interface Swimlane<T extends PhaseTask> {
    readonly member?: ProjectionMember;
    readonly name: string;
    readonly completed: readonly T[];
    readonly running: readonly T[];
    readonly queued: readonly T[];
    readonly blocked: readonly T[];
    /** Unfinished dependencies of the blocked tasks, deduplicated. */
    readonly blockedBy: readonly string[];
}
/**
 * One row per participant: what they finished, what they hold now, what they
 * can pick up next and what a failed dependency is holding back.
 *
 * A task is `queued` when every dependency reached `completed`, and `blocked`
 * otherwise (with the offending ids surfaced as {@link Swimlane.blockedBy}) —
 * that pair is what answers "why is the team standing still".
 */
export declare function agentSwimlanes<T extends PhaseTask>(tasks: readonly T[], members: readonly ProjectionMember[]): readonly Swimlane<T>[];
/** Why one participant has nothing to do right now. */
export type IdleReason = {
    readonly kind: 'no-tasks';
} | {
    readonly kind: 'all-done';
} | {
    readonly kind: 'blocked-by';
    readonly tasks: readonly string[];
} | {
    readonly kind: 'waiting-review-of';
    readonly taskId: string;
};
/** One participant's queue: what they hold, what is next, and why not. */
export interface AgentQueue<T extends PhaseTask> {
    readonly member?: ProjectionMember;
    readonly taken: readonly T[];
    readonly next?: T;
    readonly waitingOn: readonly string[];
    readonly idleReason: IdleReason;
}
/**
 * The queue view's row for one participant.
 *
 * `next` is the first claimable task assigned to them; `idleReason` says why
 * there is none, in the order the panel explains it: the member holds no work
 * at all, everything they hold is terminal, their next task waits on named
 * upstream tasks, or they are the reviewer of a task that has not finished.
 */
export declare function agentQueue<T extends PhaseTask>(tasks: readonly T[], members: readonly ProjectionMember[], member: ProjectionMember | undefined): AgentQueue<T>;
/** Locale key plus params for one idle reason. */
export interface IdleReasonSummary {
    readonly key: 'queue.idle.noTasks' | 'queue.idle.allDone' | 'queue.idle.blockedBy' | 'queue.idle.waitingReview';
    readonly params: {
        readonly tasks?: string;
        readonly taskId?: string;
    };
}
/** Translate one idle reason into its locale key and interpolation params. */
export declare function idleReasonSummary(reason: IdleReason): IdleReasonSummary;
/** One grouped idle reason of the queue overview. */
export interface IdleReasonGroup {
    readonly key: IdleReasonSummary['key'];
    readonly count: number;
}
/** Headline plus grouped reasons for the queue view. */
export interface QueueOverview {
    readonly idleCount: number;
    readonly idleTotal: number;
    readonly groups: readonly IdleReasonGroup[];
}
/**
 * Group the team's idle reasons: the direct answer to "8 of 9 are idle — why?".
 *
 * A member whose next task exists is working, not idle, and is excluded from
 * both the count and the groups.
 */
export declare function queueOverview<T extends PhaseTask>(tasks: readonly T[], members: readonly ProjectionMember[]): QueueOverview;
/**
 * Stable colour token for one agent name, identical in the tree, phase and
 * agent views. `captain` and unassigned work get their own reserved tokens so
 * they never collide with a member's colour.
 *
 * @param name - member name, `captain`, or `''` for unassigned work.
 */
export declare function agentColor(name: string): string;
/** The three read-only cuts plus the original dependency tree. */
export type ActivityViewMode = 'tree' | 'phases' | 'agents' | 'queues';
/** Persisted per-browser choice of panel view, next to the panel geometry. */
export declare const ACTIVITY_VIEW_STORAGE_KEY = "dsh-agent-teams:activity-panel:view:v1";
/** One positioned node of the phase board. */
export interface PhaseNode<T extends PhaseTask> {
    readonly task: T;
    readonly x: number;
    readonly y: number;
}
/** One dependency edge of the phase board. */
export interface PhaseEdge {
    readonly from: string;
    readonly to: string;
    readonly path: string;
}
/** A phase board laid out in fixed columns, one per phase. */
export interface PhaseBoardLayout<T extends PhaseTask> {
    readonly width: number;
    readonly height: number;
    readonly columns: readonly {
        readonly phaseId: string;
        readonly order: number;
        readonly title?: string;
        readonly x: number;
    }[];
    readonly nodes: readonly PhaseNode<T>[];
    readonly edges: readonly PhaseEdge[];
}
/** Parse a persisted view choice, falling back to the dependency tree. */
export declare function parseActivityView(raw: string | null | undefined): ActivityViewMode;
/**
 * Lay the phase board out with a fixed X per phase column.
 *
 * This is {@link compactDagLayout}'s geometry with the column taken from the
 * phase instead of the dependency depth, so a manually declared phase keeps its
 * declared order even when its tasks sit at mixed depths. Rows are assigned in
 * task-id order inside each column, and an edge is emitted for every dependency
 * whose other end also landed on the board.
 *
 * @param tasks - the team's tasks.
 * @param manualPhases - optional declared phases (WP7's `plan.phases`).
 */
export declare function phaseBoardLayout<T extends PhaseTask>(tasks: readonly T[], manualPhases?: readonly ManualPhase[]): PhaseBoardLayout<T>;
/**
 * Return the complete upstream/downstream chain around one task.
 *
 * Traversal uses both dependency directions and remains cycle-safe, so the UI
 * can highlight every handoff related to the focused task even if malformed
 * durable data contains a cycle.
 */
export declare function relatedTaskIds(taskId: string, tasks: readonly RelationshipTask[]): ReadonlySet<string>;
