/**
 * Packaged artwork route for the activity panel.
 *
 * The client builds every URL from `assets/agent-teams/` and appends the pack
 * revision as `?v=<revision>` (see `src/client/artwork.ts`), so the request URL
 * carries a query the file lookup must ignore. Only the allowlisted file names
 * are servable: the path never reaches the filesystem, which is what keeps a
 * traversal attempt a plain 404.
 *
 * The response is cacheable by name. That is safe *because* the client
 * revisions its URLs: a redrawn pack is a different URL, while an unchanged one
 * is served from the browser cache for a day without a round trip.
 * @module dsh-agent-teams/artwork
 */
/** Packaged artwork the host half is willing to serve, and nothing else. */
export declare const ART_ALLOWLIST: ReadonlySet<string>;
/** The slice of a node response this route writes. */
export interface ArtworkResponse {
    writeHead(status: number, headers?: Record<string, string>): void;
    end(body?: Uint8Array | string): void;
}
/**
 * Serve one artwork request: the allowlisted file named by the path, or 404.
 * @param dir - absolute directory holding the packaged images.
 * @param req - request whose `url` may carry the `?v=` revision.
 * @param res - response sink.
 * @param warn - logger used when an allowlisted file cannot be read.
 */
export declare function serveArtwork(dir: string, req: {
    url?: string;
}, res: ArtworkResponse, warn?: (message: string) => void): Promise<void>;
