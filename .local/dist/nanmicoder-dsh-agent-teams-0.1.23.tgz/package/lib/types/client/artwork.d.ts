/**
 * Shared mascot artwork lookup for the activity panel and the conversation
 * card: role keywords map to the packaged role images; the captain always
 * uses the lead mascot.
 *
 * Two packs are served from the same route: the amber terminal mascot carries
 * the member identity at full size, while the standalone role symbol marks the
 * same role in the small corner badge. The symbols exist as a separate pack
 * because a mascot scaled down to badge size is unreadable.
 *
 * Every URL ends with `?v=<ART_REVISION>`. The file names are stable across
 * packs — the whale and the amber terminal are both `member-engineer-v2.png` —
 * so without a revision a browser that cached the previous artwork keeps
 * drawing it for the whole `cache-control` lifetime, and a redeployed panel
 * looks unchanged. `scripts/art-revision.mjs` derives the revision from the
 * packaged bytes and both `pnpm build` and `scripts/verify.mjs` fail when the
 * committed value goes stale.
 * @module dsh-agent-teams/client/artwork
 */
/** Artwork route prefix served by the plugin host half. */
export declare const ART_BASE = "/plugins/dsh-agent-teams/assets/";
/** Captain artwork (always the lead mascot). */
export declare const LEAD_ART: string;
/** Captain role symbol for the corner badge (always the lead symbol). */
export declare const LEAD_SYMBOL: string;
/** Status action artwork per member activity. */
export declare const ACTION_ART: Record<'working' | 'idle' | 'unknown', string>;
/**
 * Standalone action symbol per member activity, drawn in the small corner
 * badge. A mascot scaled to badge size reads as a smudge; the symbol pack
 * exists for exactly this slot, the same reason the role symbol does.
 */
export declare const ACTION_SYMBOL: Record<'working' | 'idle' | 'unknown', string>;
/**
 * Member role symbol, or null when no role matches. Null means the caller
 * renders its own fallback (an initial letter on the avatar, a plain dot in a
 * dense list) rather than a symbol for a role we did not match.
 *
 * Since v0.1.22 this is the *compact* mark: the avatar no longer draws it — the
 * row names the role in words — and the dense surfaces do, where neither the
 * mascot nor the label fits.
 * @param name - the member's display name.
 * @param role - the member's role text.
 * @returns the role symbol URL, or null when unmatched.
 */
export declare function memberSymbolUrl(name: string, role: string): string | null;
/**
 * Compact identity mark for one task owner: the captain's lead mark, or the
 * role symbol of the named member.
 *
 * Dense surfaces — a DAG node head, an assignment line, a queue row — have room
 * for a 12px mark but not for the mascot or a role label, so they draw this. A
 * null answer means "no mark we can draw": an unclaimed task, or a member whose
 * role matched no keyword. Callers keep their own fallback (a coloured dot).
 * @param assignee - the task's owner as stored in the team state.
 * @param members - the team roster used to resolve a name to its role.
 * @returns the compact mark URL, or null when the owner has none.
 */
export declare function ownerSymbolUrl(assignee: string, members: readonly {
    readonly name: string;
    readonly role: string;
}[]): string | null;
/**
 * Member artwork URL, or null when no role matches (initial-letter fallback).
 * @param name - the member's display name.
 * @param role - the member's role text.
 * @returns the artwork URL, or null when unmatched.
 */
export declare function memberArtUrl(name: string, role: string): string | null;
