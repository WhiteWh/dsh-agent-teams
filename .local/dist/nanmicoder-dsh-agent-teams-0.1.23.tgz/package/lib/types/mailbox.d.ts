/** Durable delivery receipts and execution-generation filtering at step admission. */
import type { Context } from '@deepseek-ai/cordis';
import type { TeamMessage, TeamState } from './types.ts';
export declare function isCurrentMail(team: TeamState, message: TeamMessage): boolean;
export declare function mailboxPrompt(teamId: string, recipient: string, messages: readonly TeamMessage[]): string;
/** Only messages actually admitted to this recipient's step become read. */
export declare function installMailboxAdmission(ctx: Context, stateDir: string): void;
