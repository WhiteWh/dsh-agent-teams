/**
 * Pure quality-gate rules: contracts, path audit, completion, follow-up,
 * coverage, and resume. Tools and persistence call these; they do not I/O.
 * @module dsh-agent-teams/quality-gates
 */
import { type AcceptanceCriterion, type AcceptanceResult, type CommandResult, type FindingSeverity, type KnownDelta, type ReviewFinding, type ReviewPolicy, type ReviewVerdict, type TaskKind, type TaskRevision, type TaskStatus, type TeamState, type TeamTask, type WaiverConfirmation } from './types.ts';
import { TASK_TRANSITIONS } from './state.ts';
export { TASK_TRANSITIONS };
declare const QUALITY_KINDS: readonly TaskKind[];
declare const WRITE_KINDS: readonly TaskKind[];
declare const DEFAULT_REVIEW_POLICY: Required<Pick<ReviewPolicy, 'requirementsMinRounds' | 'requirementsMaxRounds' | 'codeMaxRounds' | 'maxRepairAttempts'>>;
export type PathClassification = 'in_scope' | 'out_of_scope' | 'undeclared' | 'illegal';
export interface CreateTaskInput {
    subject: string;
    description?: string;
    dependencies?: string[];
    assignee?: string;
    kind?: TaskKind;
    round?: number;
    objective?: string;
    inScope?: string[];
    outOfScope?: string[];
    /** A plain criterion, or a `{text, mode: 'no_regression', baseline?}` object. */
    acceptance?: (string | AcceptanceCriterion)[];
    verify?: string[];
    deliverables?: string[];
    nonGoals?: string[];
    reviewedTaskId?: string;
    sourceTaskId?: string;
    sourceFindingIds?: string[];
    coverageOf?: string[];
    resume?: boolean;
    resumeReason?: string;
    /**
     * The id this task will occupy once created (`t{n}`). The pure validator does
     * not allocate ids, so callers that already know the next id pass it in;
     * without it the mirror overlap direction cannot be checked.
     */
    nextTaskId?: string;
    /**
     * Paths every write task of this team inherits from the profile
     * (`taskPlanning.sharedInScope`, WP4/S10). They are excluded from the overlap
     * comparison: two sibling lanes are expected to touch shared generated docs.
     */
    sharedInScope?: string[];
}
export interface ValidateCreateTaskResult {
    ok: boolean;
    error?: string;
    kind?: TaskKind;
    task?: Partial<TeamTask>;
    team?: TeamState;
}
export interface QualityCompletionUpdate {
    status?: TaskStatus;
    output?: string;
    verdict?: ReviewVerdict;
    findings?: ReviewFinding[];
    changedPaths?: string[];
    acceptanceResults?: AcceptanceResult[];
    commandsRun?: CommandResult[];
}
export interface QualityCompletionResult {
    ok: boolean;
    error?: string;
    requiredStatus?: TaskStatus;
    /**
     * Paths the worker reported but did not declare (WP4/S10). The caller holds the
     * task in `awaiting_scope_review` instead of failing it: the captain either
     * accepts the paths with `agent_teams_accept_paths`, or reassigns/supersedes.
     */
    scopeReview?: readonly string[];
}
export interface PlannedFollowUpTask {
    id?: string;
    kind: TaskKind;
    subject?: string;
    assignee?: string;
    dependencies?: string[];
    round?: number;
    objective?: string;
    inScope?: string[];
    outOfScope?: string[];
    acceptance?: (string | AcceptanceCriterion)[];
    verify?: string[];
    sourceTaskId?: string;
    sourceFindingIds?: string[];
    reviewedTaskId?: string;
}
export interface PlanQualityFollowUpResult {
    created: PlannedFollowUpTask[];
    tasks: PlannedFollowUpTask[];
    escalated?: boolean;
    status?: 'escalated';
}
export interface CoverageRow {
    goal_item: string;
    task_ids: string[];
    status: 'missing' | 'in_progress' | 'passed' | 'blocked';
    evidence?: string;
}
export interface DeliveryResult {
    ok: boolean;
    blockers: string[];
}
export interface ResumeTeamResult {
    ok?: boolean;
    status: 'resumed' | 'already_running' | 'rejected';
    team?: TeamState;
    error?: string;
}
export type QualityLoopState = 'running' | 'halted' | 'escalated' | 'deliverable' | 'blocked';
export interface QualityLoopSnapshot {
    state: QualityLoopState;
    halted: boolean;
    escalated: boolean;
    deliverable: boolean;
    summary: string;
}
export interface QualityGraphDraft {
    subject: string;
    kind: TaskKind;
    assignee?: string;
    dependencies: string[];
    objective: string;
    acceptance: string[];
    inScope?: string[];
    verify?: string[];
    coverageOf?: string[];
}
export declare const DEFAULT_REVIEW_ACCEPTANCE: readonly ["The latest implementation meets the user goal", "No unresolved blocker or high findings"];
export declare const DEFAULT_REVIEW_OBJECTIVE = "Review whether the latest implementation satisfies the user goal";
export declare function taskKindOf(task: Pick<TeamTask, 'kind'> | undefined): TaskKind;
export declare function isQualityKind(kind: TaskKind | undefined): boolean;
export declare function resolveReviewPolicy(policy: ReviewPolicy | undefined): Required<typeof DEFAULT_REVIEW_POLICY> & ReviewPolicy;
export declare function isReviewPolicy(value: unknown): value is ReviewPolicy;
/** Normalize a workspace-relative POSIX path. `undefined` means illegal. */
export declare function normalizeWorkspacePath(path: string): string | undefined;
export declare function pathMatchesScope(path: string, pattern: string): boolean;
export declare function classifyChangedPath(path: string, inScope?: readonly string[], outOfScope?: readonly string[]): PathClassification;
export declare function collectChangedPaths(gitStatusText: string): string[];
export declare function inScopeOverlap(left: readonly string[] | undefined, right: readonly string[] | undefined): string[];
export declare function validateCreateTask(team: TeamState, input: CreateTaskInput): ValidateCreateTaskResult;
/** The display text of one acceptance criterion, whichever shape it has. */
export declare function acceptanceCriterionText(criterion: string | AcceptanceCriterion): string;
/**
 * Whether one report covers every required acceptance criterion.
 *
 * A criterion counts when its matching result is `passed` (with the baseline
 * named for a `no_regression` criterion) or `waived` with a non-empty evidence
 * string. Matching is by normalized text — see {@link normalizeCriterionText}.
 *
 * @param required - the task's acceptance criteria.
 * @param results - the submitted results.
 * @param allowWaivers - false makes every waiver an ordinary failure.
 * @returns the uncovered criterion texts, empty when everything is covered.
 */
export declare function uncoveredAcceptance(required: readonly (string | AcceptanceCriterion)[] | undefined, results: readonly AcceptanceResult[] | undefined, allowWaivers?: boolean): string[];
/** Whether one report covers every required verify command (same rules). */
export declare function uncoveredCommands(required: readonly string[] | undefined, results: readonly CommandResult[] | undefined, allowWaivers?: boolean): string[];
/** Whether a submitted result reports at least one waiver. */
export declare function reportsWaiver(results: readonly {
    status: string;
}[] | undefined): boolean;
/** Whether one task's own latest report contains waivers. */
export declare function taskHasWaivers(task: TeamTask): boolean;
/** Whether a review task has confirmed the waivers of the task it judged. */
export declare function waiversConfirmed(team: TeamState, task: TeamTask): boolean;
/** The ids of every task whose waivers still need a reviewer's confirmation. */
export declare function unconfirmedWaivers(team: TeamState): string[];
export declare function evaluateQualityCompletion(task: TeamTask, update: QualityCompletionUpdate, allowWaivers?: boolean): QualityCompletionResult;
/** Whether one durable known-delta entry is well-formed (WP6.3). */
export declare function isKnownDelta(value: unknown): value is KnownDelta;
/** The pinned delta whose `check` matches a command or criterion text. */
export declare function pinnedDeltaFor(deltas: readonly KnownDelta[] | undefined, text: string): KnownDelta | undefined;
/**
 * The evidence a pinned delta supplies for a waiver of one check (WP6.3), or
 * undefined when nothing is pinned for that command/criterion.
 */
export declare function pinnedWaiverEvidence(deltas: readonly KnownDelta[] | undefined, text: string): string | undefined;
/** Outcome of {@link pinKnownDelta} / {@link unpinKnownDelta}. */
export interface KnownDeltaMutation {
    ok: boolean;
    error?: string;
    deltas?: KnownDelta[];
    delta?: KnownDelta;
}
/**
 * Pin one known delta (WP6.3). `check` is the identity: a second pin for the same
 * check is refused and names the existing entry, because two reasons for one red
 * check would make the auto evidence ambiguous and hide a stale pin.
 */
export declare function pinKnownDelta(deltas: readonly KnownDelta[] | undefined, input: {
    id?: string;
    check: string;
    expected: string;
    reason: string;
    pinnedBy: string;
    at?: number;
}): KnownDeltaMutation;
/** Remove one known delta by id (WP6.3). */
export declare function unpinKnownDelta(deltas: readonly KnownDelta[] | undefined, id: string): KnownDeltaMutation;
/** Result of {@link acceptTaskPaths}. */ export interface AcceptPathsResult {
    ok: boolean;
    error?: string;
    task?: TeamTask;
    revision?: TaskRevision;
}
/**
 * Post-hoc scope acceptance (WP4/S10): add paths to a task's `inScope` instead of
 * replacing the list.
 *
 * The worker reports what it really changed; when a path is outside the declared
 * scope the gate holds the task in `awaiting_scope_review` and the captain either
 * accepts the paths here — the lane then completes with the work it actually did
 * — or reassigns/supersedes it. Acceptance is additive on purpose: `amend_task`
 * replaces whole lists, which is the wrong shape for "also allow these files".
 *
 * A `completed` task may still accept paths (that is the point of "post-hoc"), as
 * long as no review has passed judgment on it; `force` overrides that freeze
 * exactly like a contract amendment, and the acceptance is recorded in the same
 * revisions ledger.
 * @param team - the team record, read for the freeze check.
 * @param task - the task whose scope is widened.
 * @param paths - workspace-relative paths to add.
 * @param by - author identity (`captain`).
 * @param reason - why the paths belong to the lane.
 * @param force - allow widening after a passing review verdict.
 * @returns the updated task plus the recorded revision.
 */
export declare function acceptTaskPaths(team: TeamState, task: TeamTask, paths: readonly string[], by: string, reason: string, force?: boolean): AcceptPathsResult;
/**
 * Derive the repair round's inScope from the findings that caused it.
 *
 * `finding.file` records where the problem was OBSERVED, but the fix often
 * targets a different file named in `requiredFix` (docs vs sample data,
 * config vs code). Deriving the scope from both keeps the auto-generated
 * repair contract satisfiable; deriving from `file` alone can produce a
 * contract where the acceptance ("edit README.md") names a path the scope
 * forbids, so no honest completion exists and the repair dead-locks.
 *
 * Absolute and otherwise illegal paths are dropped (they can never match
 * workspace-relative scope patterns anyway); when nothing legal remains,
 * the source task's own inScope is kept as the fallback. Over-inclusion is
 * accepted: inScope is an audit upper bound, and the requiredFix text still
 * tells the implementer what to touch.
 *
 * Keep all derived paths until the generator resolves inherited exclusions;
 * filtering first would silently discard a required fix target.
 */
export declare function repairScopeFromFindings(findings: readonly ReviewFinding[], fallback: string[] | undefined): string[] | undefined;
/** Captain-only amendment payload: replacement values for contract fields. */
export interface ContractAmendmentInput {
    objective?: string;
    acceptance?: string[];
    verify?: string[];
    inScope?: string[];
    outOfScope?: string[];
    deliverables?: string[];
    nonGoals?: string[];
    reviewedTaskId?: string;
    /** Work tasks have no quality contract, but their brief is still amendable. */
    subject?: string;
    description?: string;
}
export interface AmendTaskContractResult {
    ok: boolean;
    error?: string;
    task?: TeamTask;
    revision?: TaskRevision;
    /**
     * Review / requirements tasks whose passing verdict the forced amendment
     * invalidated. Callers must persist them alongside {@link task}: their verdict
     * becomes `stale`, so delivery can no longer treat the changed contract as
     * reviewed.
     */
    invalidatedReviews?: readonly TeamTask[];
}
/**
 * Controlled contract amendment (the pure rule; tooling keeps it
 * captain-only). When a quality contract is wrong — a verify command that
 * cannot pass, an inScope that forbids the file the objective names — the
 * worker has no honest completion and either dead-locks or games the gate.
 * Instead the captain may fix the contract mid-flight: every amendment is
 * recorded on the task as a {@link TaskRevision} (previous values + reason),
 * and once a review/requirements task has passed judgment on this task the
 * contract is frozen. Amendments replace whole fields (lists are full
 * replacements, not deltas); the implementer re-reads the amended contract
 * before its next quality gate. Completion gates need no special casing:
 * they read the task's current fields, so they naturally evaluate the
 * amended contract.
 *
 * A `failed` task is amendable — that is the first step of the retry, not a
 * rewrite of history — while `completed` and `cancelled` stay immutable. The
 * freeze after a passing verdict can be overridden with `force`, which demands
 * the same non-empty reason and additionally stales the verdict that judged the
 * old contract; otherwise a contract that turned out to be wrong could only be
 * fixed by cancelling and recreating the lane.
 */
export declare function amendTaskContract(team: TeamState, task: TeamTask, input: ContractAmendmentInput, by: string, reason: string, force?: boolean): AmendTaskContractResult;
export declare function planQualityFollowUp(team: TeamState, closed: TeamTask): PlanQualityFollowUpResult;
export declare function buildCoverageMatrix(goalItems: readonly string[], tasks: readonly TeamTask[]): CoverageRow[];
export declare function canDeclareDelivery(team: TeamState): DeliveryResult;
export declare function resumeTeamState(team: TeamState, reason: string): ResumeTeamResult;
export declare function isReviewFinding(value: unknown): value is ReviewFinding;
export declare function isAcceptanceResult(value: unknown): value is AcceptanceResult;
/** Validate one acceptance criterion: a plain string, or `{text, mode?, baseline?}`. */
export declare function isAcceptanceCriterion(value: unknown): value is string | AcceptanceCriterion;
/** Validate one review waiver confirmation. */
export declare function isWaiverConfirmation(value: unknown): value is WaiverConfirmation;
export declare function isCommandResult(value: unknown): value is CommandResult;
export declare function isTaskRevision(value: unknown): value is TaskRevision;
/**
 * Normalize blank optional task fields to omitted ("blank means absent").
 * Blank string scalars are deleted; string lists have blank entries filtered
 * out, and a list that only contained blanks is omitted entirely. Non-blank
 * values and every other field are passed through untouched, so durable-state
 * validation stays strict.
 */
export declare function normalizeBlankOptionalTaskFields<T extends object>(task: T): T;
export declare function hasValidQualityTaskFields(value: Record<string, unknown>): boolean;
export declare function isTaskKind(value: unknown): value is TaskKind;
export declare function isReviewVerdict(value: unknown): value is ReviewVerdict;
export declare function isFindingSeverity(value: unknown): value is FindingSeverity;
export declare function looksLikeGateTestContract(value: string | undefined): boolean;
export declare function sanitizeReviewObjective(value: string | undefined, fallback?: string): string;
/** Normalize review acceptance criteria coming from another review contract. */
export declare function sanitizeReviewAcceptance(values: readonly (string | AcceptanceCriterion)[] | undefined): string[];
export declare function defaultQualityDeliveryGraph(input: {
    goal: string;
    implementer?: string;
    reviewer?: string;
    analyst?: string;
    tester?: string;
    integrator?: string;
}): QualityGraphDraft[];
export declare function qualityPlanningPrompt(): string;
export declare function describeQualityLoop(team: TeamState): QualityLoopSnapshot;
export { QUALITY_KINDS, WRITE_KINDS };
export { findProfilesInConfig, lintProfileKeys } from './profiles.ts';
