/**
 * Plan progress (WP8).
 *
 * One percentage for a whole team, computed on the server so the text status,
 * the conversation card and the activity panel cannot disagree. Two modes are
 * returned together — a kind-weighted one and an equal one — because the panel
 * switches between them without a second round trip; the profile only picks
 * which of the two is the default.
 *
 * Percent rule: `Σ weight(completed) / Σ weight(total − cancelled − superseded)`.
 * Tasks that were cancelled or replaced by a supersede are not work the team
 * still owes, so they leave the denominator instead of counting as failure.
 * A plan with nothing left in the denominator reports 0 percent rather than
 * inventing 100.
 */
import type { TaskOrigin, TeamTask } from './types.ts';
/** The default weight of every task kind (`taskPlanning.weights` overrides it). */
export declare const PROGRESS_KIND_WEIGHTS: Readonly<Record<string, number>>;
/** The weight of a task whose kind is unknown or absent. */
export declare const PROGRESS_DEFAULT_WEIGHT = 1;
/** How the headline percentage is computed. */
export type ProgressMode = 'byKind' | 'equal';
/** A resolved weight table: the mode the profile asked for plus the kind table. */
export interface ProgressWeightTable {
    readonly mode: ProgressMode;
    /** The kind table; still filled in `equal` mode so a later switch is honest. */
    readonly byKind: Readonly<Record<string, number>>;
}
/** A declared phase, e.g. `plan.phases` or `taskPlanning.phases`. */
export interface ProgressPhaseGroup {
    readonly id: string;
    readonly title?: string;
    /** Tasks of this phase; tasks missing from every group fall into `unphased`. */
    readonly taskIds: readonly string[];
    /** Set once the captain closed the phase (round 3); it takes no new work. */
    readonly closed?: boolean;
}
/**
 * Progress and status of one phase row.
 *
 * Φ1 feedback F7.3: the owner asked to see «Φ2: 12 lanes, 4 verified, 1 failed, 2 pins»
 * without asking the captain in chat. The counts below are that answer for one phase;
 * `verified` is the brief's word for work a passing review or verification judged, and
 * `pinned` counts the known deltas (pins) registered for the team.
 */
export interface PlanProgressPhase {
    readonly phaseId: string;
    readonly title?: string;
    readonly completed: number;
    readonly total: number;
    readonly percentByKind: number;
    readonly percentEqual: number;
    readonly running: number;
    readonly blocked: number;
    readonly failed: number;
    readonly cancelled: number;
    readonly superseded: number;
    readonly waived: number;
    /** Completed lanes a passing review/verification judged. */
    readonly verified: number;
    readonly closed?: boolean;
}
/** The plan progress of one team. */
export interface PlanProgress {
    /** The mode the team's profile prefers (`byKind` unless it asked for `equal`). */
    readonly mode: ProgressMode;
    /** `percentByKind` or `percentEqual`, whichever `mode` selects. */
    readonly percent: number;
    readonly percentByKind: number;
    readonly percentEqual: number;
    /** Every task of the team, including the cancelled and superseded ones. */
    readonly total: number;
    readonly completed: number;
    readonly running: number;
    readonly blocked: number;
    readonly failed: number;
    /** Failed quality lanes that already have their follow-up repair (WP7). */
    readonly repaired: number;
    /** Completed tasks that carry waivers. */
    readonly waived: number;
    readonly superseded: number;
    readonly cancelled: number;
    /** One row per phase (declared phases, otherwise the DAG levels). */
    readonly byPhase: readonly PlanProgressPhase[];
    /**
     * Round 3: how much of the work is the original plan, how much the captain added
     * while it ran, and how much arrived after the plan had settled. One bar, three
     * colours — see the owner decision in `.local/PROGRESS.md` (D7).
     */
    readonly segments: readonly PlanProgressSegment[];
}
/** One stretch of a plan's life, as the progress bar colours it. */
export interface PlanProgressSegment {
    readonly origin: TaskOrigin;
    readonly completed: number;
    readonly total: number;
    readonly percent: number;
}
/** The three stretches, in the order the bar draws them. */
export declare const TASK_ORIGINS: readonly TaskOrigin[];
/**
 * Validate and resolve the `taskPlanning.weights` value of a profile.
 * @param value - `'equal'`, a per-kind weight table, or `undefined` for defaults.
 * @returns the mode plus the kind table (never the caller's own object).
 */
export declare function resolveProgressWeights(value: string | Readonly<Record<string, unknown>> | undefined): ProgressWeightTable;
/**
 * Compute the plan progress of one team.
 * @param tasks - the team's durable tasks.
 * @param options - `weights` (`'equal'` or a per-kind table) and declared `phases`.
 * @returns the counts, both percentages and the per-phase rows.
 */
export declare function planProgress(tasks: readonly TeamTask[], options?: {
    readonly weights?: string | Readonly<Record<string, unknown>>;
    readonly phases?: readonly ProgressPhaseGroup[];
}): PlanProgress;
