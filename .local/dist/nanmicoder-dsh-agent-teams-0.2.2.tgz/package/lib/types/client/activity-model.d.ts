/** Pure relationship projections used by the AgentTeams activity panel. */
/** Reference-panel geometry: narrow nodes with enough room for curved edges. */
export declare const COMPACT_DAG_NODE_WIDTH = 92;
export declare const COMPACT_DAG_NODE_HEIGHT = 30;
export declare const COMPACT_DAG_COLUMN_GAP = 26;
export declare const COMPACT_DAG_ROW_GAP = 8;
/** Compact `provider/model` route, or just the model when the provider is absent. */
export declare function memberRouteLabel(member: {
    readonly provider?: string;
    readonly model?: string;
} | undefined): string;
/**
 * Compact route shown on a running task. Prefer the task's own snapshot
 * field; fall back to the assignee member when older hosts omit it.
 */
export declare function taskModelLabel(task: {
    readonly model?: string;
    readonly assignee: string;
}, members: readonly {
    readonly name: string;
    readonly provider?: string;
    readonly model?: string;
}[]): string;
/** Short model id for tight DAG/chip surfaces (`openai/gpt-5.6-sol` → `gpt-5.6-sol`). */
export declare function compactModelLabel(route: string): string;
/** Where the panel remembers which team the reader is looking at. */
export declare const PANEL_TEAM_STORAGE_KEY = "dsh-agent-teams:activity-panel:team:v1";
/** One tab of the panel's team switcher. */
export interface PanelTeamTab {
    readonly teamId: string;
    readonly name: string;
    readonly halted: boolean;
    readonly phase: string;
    /** Members currently working, for the tab's activity dot. */
    readonly working: number;
    readonly done: number;
    readonly total: number;
}
/**
 * The tabs of the team switcher: one per live team of the current session, in
 * the order the snapshots arrive. Counters come from each team's own tasks, so a
 * tab can never report another team's work.
 */
export declare function panelTeamTabs<T extends {
    readonly teamId: string;
    readonly name: string;
    readonly halted?: boolean;
    readonly phase?: string;
    readonly members: readonly {
        readonly status?: string;
        readonly activity?: string;
    }[];
    readonly tasks: readonly {
        readonly status: string;
    }[];
}>(teams: readonly T[]): readonly PanelTeamTab[];
/** A stored switcher preference, trimmed; `null` when nothing usable was stored. */
export declare function parsePanelTeamSelection(raw: string | null | undefined): string | null;
/**
 * Which team the panel shows: the stored choice while that team still exists,
 * otherwise the first live team. A halted team stays selectable — it is stopped
 * work, not hidden work — and an empty session has no selection at all.
 */
export declare function panelSelectedTeamId<T extends {
    readonly teamId: string;
}>(teams: readonly T[], stored: string | null | undefined): string | null;
/** Whether the captain chat should keep showing the in-progress banner. */
export declare function teamIsActive(team: {
    readonly phase?: string;
    readonly halted?: boolean;
    readonly members: readonly {
        readonly status?: string;
        readonly activity?: string;
    }[];
    readonly tasks: readonly {
        readonly status: string;
    }[];
}): boolean;
/** Compact banner copy: running members, otherwise the current planning state. */
export declare function teamProgressSummary(team: {
    readonly members: readonly {
        readonly name: string;
        readonly status?: string;
        readonly activity?: string;
        readonly currentTask?: string;
    }[];
    readonly tasks: readonly {
        readonly id: string;
        readonly subject: string;
        readonly status: string;
    }[];
}, separator: string): {
    readonly working: number;
    readonly detail: string;
};
/** How the headline percentage is computed. Both numbers arrive from the host. */
export type ProgressMode = 'byKind' | 'equal';
/** Where the panel remembers the reader's progress-mode choice. */
export declare const PROGRESS_MODE_STORAGE_KEY = "dsh-agent-teams:activity-panel:progress:v1";
/**
 * The progress block as the panel renders it.
 *
 * The panel shows one bar. The snapshot also publishes a per-phase roll-up
 * (`byPhase`) and the wire mirror below keeps it, but no view field surfaces it:
 * the owner read the row-per-phase block as a wall of bars and removed it
 * (2026-09-20, round 2), so the selector deliberately has nothing to map.
 */
export interface PlanProgressView {
    readonly mode: ProgressMode;
    readonly percent: number;
    readonly percentByKind: number;
    readonly percentEqual: number;
    readonly completed: number;
    readonly total: number;
    readonly running: number;
    readonly blocked: number;
    readonly failed: number;
    readonly waived: number;
    readonly superseded: number;
    readonly cancelled: number;
}
/**
 * The host progress payload, mirrored structurally (see activity-monitor).
 * `byPhase` is part of the published snapshot, not of what the panel draws.
 */
interface ProgressPayload {
    readonly mode: ProgressMode;
    readonly percentByKind: number;
    readonly percentEqual: number;
    readonly completed: number;
    readonly total: number;
    readonly running: number;
    readonly blocked: number;
    readonly failed: number;
    readonly waived: number;
    readonly superseded: number;
    readonly cancelled: number;
    readonly byPhase: readonly {
        phaseId: string;
        title?: string;
        percentByKind: number;
        percentEqual: number;
        completed: number;
        total: number;
    }[];
}
/** A stored progress-mode preference, or `null` when nothing usable was stored. */
export declare function parseProgressMode(raw: string | null | undefined): ProgressMode | null;
/**
 * The progress block of one team: the host's two percentages, with the one the
 * reader asked for selected. The math stays on the server (WP8) — this selector
 * only picks a number and follows the mode switch, so the text report, the
 * conversation card and the panel cannot drift apart.
 *
 * A synthetic team (a legacy card rebuilt without a snapshot payload) has no
 * host numbers; it falls back to the equal count over its own tasks.
 *
 * @param team - the team snapshot, with or without a `progress` payload.
 * @param mode - the requested mode, or undefined for the team's default.
 * @returns the numbers the panel draws.
 */
export declare function planProgress(team: {
    readonly tasks: readonly {
        readonly status: string;
        readonly state?: string;
    }[];
    readonly progress?: ProgressPayload;
}, mode?: ProgressMode | null): PlanProgressView;
/** The four states a checklist row can show. */
export type ChecklistTone = 'done' | 'open' | 'running' | 'failed';
/**
 * The checkbox of one task status: the glyph the checklist row draws plus the
 * tone its styling keys off. A cancelled or superseded task is a crossed box —
 * it is settled and will not be delivered.
 */
export declare function taskCheckGlyph(status: string): {
    readonly tone: ChecklistTone;
    readonly glyph: string;
};
/**
 * Whether an expanded activity panel still belongs to the current session.
 *
 * The panel is mounted in the root-scoped shell overlay, so React does not
 * remount it when the conversation route changes. Ownership keeps an expanded
 * panel from leaking onto the new-session screen (or another conversation)
 * while its local open state is being reset.
 */
export declare function activityPanelExpandedForSession(open: boolean, owner: string | undefined, current: string | undefined): boolean;
/** Inputs for deciding whether genuinely new live work may expand the panel. */
export interface ActivityPanelAutoExpandInput {
    readonly alreadyAutoOpened: boolean;
    readonly pageSettled: boolean;
    readonly restoreComplete: boolean;
    readonly previousLiveTeamIds: ReadonlySet<string>;
    readonly currentLiveTeamIds: readonly string[];
}
/**
 * Auto-expand only for live teams that appear after the current session's
 * initial restore pass. Replayed cards, archived teams, and live teams restored
 * while reopening a conversation must remain behind the collapsed badge.
 */
export declare function activityPanelShouldAutoExpand({ alreadyAutoOpened, pageSettled, restoreComplete, previousLiveTeamIds, currentLiveTeamIds, }: ActivityPanelAutoExpandInput): boolean;
/**
 * Whether a task is settled: done, red, or dead (cancelled, or replaced by
 * another task). A superseded task will never finish, so every projection that
 * asks "is this lane over" must treat it like the other terminal statuses.
 */
export declare function settledTask(status: string): boolean;
/** One task as the phase board needs to see it. */
export interface PhaseTask {
    readonly id: string;
    readonly subject?: string;
    readonly status: string;
    readonly assignee: string;
    readonly dependencies: readonly string[];
    readonly state?: string;
    readonly kind?: string;
    readonly round?: number;
    readonly depth?: number;
    /** Set on a review task: the task it judges, so a blocked review stays visible. */
    readonly reviewedTaskId?: string;
}
/** A manually declared phase (comes from `plan.phases` once WP7 lands). */
export interface ManualPhase {
    readonly id: string;
    readonly title?: string;
    readonly taskIds: readonly string[];
}
/** One phase column of the phase board. */
export interface PhaseColumn<T extends PhaseTask> {
    /** `level-N` for a derived column, or the manual phase id. */
    readonly phaseId: string;
    readonly order: number;
    readonly title?: string;
    readonly tasks: readonly T[];
}
/**
 * Phase columns for the phase board.
 *
 * Manual phases win when they are present (WP7 stores them in `plan.phases`);
 * every task they do not mention falls back into an auto-derived column built
 * from the DAG levels, so a partially declared plan still renders completely.
 * Levels are computed here from the task list, not read from the snapshot's
 * `depth`, so the column count cannot silently disagree with the dependency
 * edges the panel draws.
 *
 * @param tasks - the team's tasks.
 * @param manualPhases - optional declared phases.
 * @returns the columns in display order, left to right.
 */
export declare function phaseColumns<T extends PhaseTask>(tasks: readonly T[], manualPhases?: readonly ManualPhase[]): readonly PhaseColumn<T>[];
/**
 * Stable colour token for one agent name, identical on the phase board and in
 * the member list. `captain` and unassigned work get their own reserved tokens so
 * they never collide with a member's colour.
 *
 * @param name - member name, `captain`, or `''` for unassigned work.
 */
export declare function agentColor(name: string): string;
/** One positioned node of the phase board. */
export interface PhaseNode<T extends PhaseTask> {
    readonly task: T;
    readonly x: number;
    readonly y: number;
}
/** One dependency edge of the phase board. */
export interface PhaseEdge {
    readonly from: string;
    readonly to: string;
    readonly path: string;
}
/** A phase board: one flexible column per phase, chains laid out inside it. */
export interface PhaseBoardLayout<T extends PhaseTask> {
    readonly width: number;
    readonly height: number;
    readonly columns: readonly {
        readonly phaseId: string;
        readonly order: number;
        readonly title?: string;
        /** Left edge of the column; the column spans {@link width}. */
        readonly x: number;
        /** How wide this column grew to fit its longest same-phase chain. */
        readonly width: number;
        /** Task ids of this column, so a reader never has to infer them from x. */
        readonly taskIds: readonly string[];
    }[];
    readonly nodes: readonly PhaseNode<T>[];
    readonly edges: readonly PhaseEdge[];
}
/**
 * Lay the phase board out: one column per phase, and inside a column the work
 * runs left to right along its own chain.
 *
 * The owner's request (2026-09-20, round 2): a phase that contains sequential
 * work must read as a line rather than a stack, and the column stretches to fit
 * the longest chain it holds. So a task's x inside its column is its **chain
 * depth** — the longest path of dependencies that live in the same phase — and
 * its row is the row its same-column predecessors already use when they agree,
 * otherwise the first free row at that depth. Parallel work therefore keeps its
 * own row while a chain stays on one line, which is what makes a separate tree
 * view unnecessary. An edge is emitted for every dependency whose other end also
 * landed on the board.
 *
 * @param tasks - the team's tasks.
 * @param manualPhases - optional declared phases (WP7's `plan.phases`).
 */
export declare function phaseBoardLayout<T extends PhaseTask>(tasks: readonly T[], manualPhases?: readonly ManualPhase[]): PhaseBoardLayout<T>;
export {};
