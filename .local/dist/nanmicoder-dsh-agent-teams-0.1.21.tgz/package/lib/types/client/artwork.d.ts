/**
 * Shared mascot artwork lookup for the activity panel and the conversation
 * card: role keywords map to the packaged role images; the captain always
 * uses the lead mascot.
 *
 * Two packs are served from the same route: the amber terminal mascot carries
 * the member identity at full size, while the standalone role symbol marks the
 * same role in the small corner badge. The symbols exist as a separate pack
 * because a mascot scaled down to badge size is unreadable.
 * @module dsh-agent-teams/client/artwork
 */
/** Artwork route prefix served by the plugin host half. */
export declare const ART_BASE = "/plugins/dsh-agent-teams/assets/";
/** Captain artwork (always the lead mascot). */
export declare const LEAD_ART = "/plugins/dsh-agent-teams/assets/team-lead-v2.png";
/** Captain role symbol for the corner badge (always the lead symbol). */
export declare const LEAD_SYMBOL: string;
/** Status action artwork per member activity. */
export declare const ACTION_ART: Record<'working' | 'idle' | 'unknown', string>;
/**
 * Standalone action symbol per member activity, drawn in the small corner
 * badge. A mascot scaled to badge size reads as a smudge; the symbol pack
 * exists for exactly this slot, the same reason the role symbol does.
 */
export declare const ACTION_SYMBOL: Record<'working' | 'idle' | 'unknown', string>;
/**
 * Member role symbol (the small corner badge mark), or null when no role
 * matches. Null means the avatar already falls back to the initial letter, so
 * the caller renders no badge rather than a symbol for a role we did not match.
 * @param name - the member's display name.
 * @param role - the member's role text.
 * @returns the role symbol URL, or null when unmatched.
 */
export declare function memberSymbolUrl(name: string, role: string): string | null;
/**
 * Member artwork URL, or null when no role matches (initial-letter fallback).
 * @param name - the member's display name.
 * @param role - the member's role text.
 * @returns the artwork URL, or null when unmatched.
 */
export declare function memberArtUrl(name: string, role: string): string | null;
